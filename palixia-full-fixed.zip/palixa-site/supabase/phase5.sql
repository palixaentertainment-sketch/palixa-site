-- Palixia: likes, chapter comments, reports, reading shelves, content warnings and search filters.
-- Run this AFTER schema.sql (and seed.sql if you used it). Paste the WHOLE file into
-- Supabase > SQL Editor > New query, press Select all, then Run.
--
-- It only ADDS things. It does not delete or change any existing user, book, chapter, bookmark
-- or reading data. It is safe to run a second time.

------------------------------------------------------------------------------
-- 1. New columns on existing tables
------------------------------------------------------------------------------

alter table public.books
  add column if not exists like_count int not null default 0,
  add column if not exists audience text not null default 'everyone',
  add column if not exists completion text not null default 'ongoing',
  add column if not exists warnings text[] not null default '{}';

alter table public.chapters
  add column if not exists like_count int not null default 0;

-- Which shelf a saved book sits on in the reader's library.
alter table public.bookmarks
  add column if not exists shelf text not null default 'want';

do $$
begin
  if not exists (select 1 from pg_constraint where conname = 'books_audience_check') then
    alter table public.books add constraint books_audience_check check (audience in ('everyone', 'teen', 'mature'));
  end if;
  if not exists (select 1 from pg_constraint where conname = 'books_completion_check') then
    alter table public.books add constraint books_completion_check check (completion in ('ongoing', 'completed'));
  end if;
  if not exists (select 1 from pg_constraint where conname = 'books_warnings_check') then
    alter table public.books add constraint books_warnings_check
      check (warnings <@ array['violence', 'sexual_content', 'strong_language', 'abuse', 'self_harm', 'death', 'disturbing']::text[]);
  end if;
  if not exists (select 1 from pg_constraint where conname = 'bookmarks_shelf_check') then
    alter table public.bookmarks add constraint bookmarks_shelf_check check (shelf in ('want', 'reading', 'finished'));
  end if;
end $$;

-- Authors may set the new descriptive fields on their own books. Counts stay locked.
grant insert (audience, completion, warnings) on public.books to authenticated;
grant update (audience, completion, warnings) on public.books to authenticated;

------------------------------------------------------------------------------
-- 2. Likes (a reader's own like is private to them, only the total is public)
------------------------------------------------------------------------------

create table if not exists public.book_likes (
  user_id uuid not null references public.profiles(id) on delete cascade,
  book_id uuid not null references public.books(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, book_id)
);

create table if not exists public.chapter_likes (
  user_id uuid not null references public.profiles(id) on delete cascade,
  chapter_id uuid not null references public.chapters(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, chapter_id)
);

alter table public.book_likes enable row level security;
alter table public.chapter_likes enable row level security;

drop policy if exists "see own book likes" on public.book_likes;
drop policy if exists "like a book" on public.book_likes;
drop policy if exists "unlike a book" on public.book_likes;
create policy "see own book likes" on public.book_likes for select using (auth.uid() = user_id);
create policy "like a book" on public.book_likes for insert with check (
  auth.uid() = user_id
  and exists (select 1 from public.books b where b.id = book_id and b.status = 'published' and b.author_id <> auth.uid())
);
create policy "unlike a book" on public.book_likes for delete using (auth.uid() = user_id);

drop policy if exists "see own chapter likes" on public.chapter_likes;
drop policy if exists "like a chapter" on public.chapter_likes;
drop policy if exists "unlike a chapter" on public.chapter_likes;
create policy "see own chapter likes" on public.chapter_likes for select using (auth.uid() = user_id);
create policy "like a chapter" on public.chapter_likes for insert with check (
  auth.uid() = user_id
  and exists (
    select 1 from public.chapters c join public.books b on b.id = c.book_id
    where c.id = chapter_id and c.status = 'published' and b.status = 'published' and b.author_id <> auth.uid()
  )
);
create policy "unlike a chapter" on public.chapter_likes for delete using (auth.uid() = user_id);

grant select, insert, delete on public.book_likes, public.chapter_likes to authenticated;

-- Keeps the public totals right. Only these triggers can change like_count.
create or replace function public.count_book_like()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    update public.books set like_count = like_count + 1 where id = new.book_id;
  else
    update public.books set like_count = greatest(like_count - 1, 0) where id = old.book_id;
  end if;
  return null;
end;
$$;

create or replace function public.count_chapter_like()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    update public.chapters set like_count = like_count + 1 where id = new.chapter_id;
  else
    update public.chapters set like_count = greatest(like_count - 1, 0) where id = old.chapter_id;
  end if;
  return null;
end;
$$;

drop trigger if exists book_like_count on public.book_likes;
create trigger book_like_count after insert or delete on public.book_likes
  for each row execute function public.count_book_like();

drop trigger if exists chapter_like_count on public.chapter_likes;
create trigger chapter_like_count after insert or delete on public.chapter_likes
  for each row execute function public.count_chapter_like();

------------------------------------------------------------------------------
-- 3. Chapter comments (with one level of replies)
------------------------------------------------------------------------------

create table if not exists public.comments (
  id uuid primary key default gen_random_uuid(),
  chapter_id uuid not null references public.chapters(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  parent_id uuid references public.comments(id) on delete cascade,
  body text not null check (char_length(btrim(body)) between 1 and 1000),
  status text not null default 'visible' check (status in ('visible', 'hidden')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists comments_chapter_idx on public.comments (chapter_id, created_at);
create index if not exists comments_user_idx on public.comments (user_id, created_at);

alter table public.comments enable row level security;

drop policy if exists "read comments" on public.comments;
drop policy if exists "write comments" on public.comments;
drop policy if exists "edit own comments" on public.comments;
drop policy if exists "remove comments" on public.comments;

-- Anyone can read visible comments on published chapters. People always see their own,
-- and a book's author or an admin sees every comment on that book (including hidden ones).
create policy "read comments" on public.comments for select using (
  user_id = auth.uid()
  or public.is_admin()
  or exists (
    select 1 from public.chapters c join public.books b on b.id = c.book_id
    where c.id = comments.chapter_id
      and (
        b.author_id = auth.uid()
        or (comments.status = 'visible' and c.status = 'published' and b.status = 'published')
      )
  )
);

create policy "write comments" on public.comments for insert with check (
  user_id = auth.uid()
  and exists (select 1 from public.profiles p where p.id = auth.uid() and p.status = 'active')
  and exists (
    select 1 from public.chapters c join public.books b on b.id = c.book_id
    where c.id = chapter_id and c.status = 'published' and b.status = 'published'
  )
);

create policy "edit own comments" on public.comments for update
  using (user_id = auth.uid()) with check (user_id = auth.uid());

-- Delete your own, or any comment on your own book, or anything if you are an admin.
create policy "remove comments" on public.comments for delete using (
  user_id = auth.uid()
  or public.is_admin()
  or exists (
    select 1 from public.chapters c join public.books b on b.id = c.book_id
    where c.id = comments.chapter_id and b.author_id = auth.uid()
  )
);

revoke insert, update on public.comments from anon, authenticated;
grant select on public.comments to anon, authenticated;
grant delete on public.comments to authenticated;
grant insert (chapter_id, parent_id, body, user_id) on public.comments to authenticated;
grant update (body, updated_at) on public.comments to authenticated;

-- Replies stay on the same chapter and only go one level deep. A person can post at most
-- 8 comments a minute, which stops floods.
create or replace function public.check_comment()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  v_parent public.comments;
begin
  if new.parent_id is not null then
    select * into v_parent from public.comments where id = new.parent_id;
    if v_parent.id is null or v_parent.chapter_id <> new.chapter_id or v_parent.parent_id is not null then
      raise exception 'invalid_reply';
    end if;
  end if;
  if (select count(*) from public.comments where user_id = new.user_id and created_at > now() - interval '1 minute') >= 8 then
    raise exception 'too_many_comments';
  end if;
  new.body := btrim(new.body);
  return new;
end;
$$;

drop trigger if exists comment_checks on public.comments;
create trigger comment_checks before insert on public.comments
  for each row execute function public.check_comment();

------------------------------------------------------------------------------
-- 4. Reports (readers flag a comment or a book; you review them in the dashboard or here)
------------------------------------------------------------------------------

create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null default auth.uid() references public.profiles(id) on delete cascade,
  target_type text not null check (target_type in ('comment', 'book')),
  target_id uuid not null,
  reason text not null check (reason in ('spam', 'abuse', 'copyright', 'inappropriate', 'other')),
  details text check (char_length(details) <= 500),
  status text not null default 'open' check (status in ('open', 'reviewed', 'dismissed')),
  created_at timestamptz not null default now(),
  unique (reporter_id, target_type, target_id)
);
create index if not exists reports_status_idx on public.reports (status, created_at desc);

alter table public.reports enable row level security;

drop policy if exists "file a report" on public.reports;
drop policy if exists "see own reports" on public.reports;
drop policy if exists "admins review reports" on public.reports;
create policy "file a report" on public.reports for insert with check (reporter_id = auth.uid());
create policy "see own reports" on public.reports for select using (reporter_id = auth.uid() or public.is_admin());
create policy "admins review reports" on public.reports for update using (public.is_admin()) with check (public.is_admin());

revoke insert, update on public.reports from anon, authenticated;
grant select on public.reports to authenticated;
grant insert (target_type, target_id, reason, details) on public.reports to authenticated;
grant update (status) on public.reports to authenticated;

-- A report must point at something that exists.
create or replace function public.check_report()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.target_type = 'comment' and not exists (select 1 from public.comments where id = new.target_id) then
    raise exception 'report_target_missing';
  end if;
  if new.target_type = 'book' and not exists (select 1 from public.books where id = new.target_id and status = 'published') then
    raise exception 'report_target_missing';
  end if;
  return new;
end;
$$;

drop trigger if exists report_checks on public.reports;
create trigger report_checks before insert on public.reports
  for each row execute function public.check_report();

------------------------------------------------------------------------------
-- 5. Catalogue view with the new fields (adds columns at the end, nothing is removed)
------------------------------------------------------------------------------

create or replace view public.book_cards with (security_invoker = true) as
select
  b.id, b.author_id, b.title, b.description, b.cover_url, b.book_type, b.tags,
  b.reads, b.featured, b.is_sample, b.created_at,
  b.genre_id, g.name as genre_name, g.slug as genre_slug,
  p.name as author_name, p.username as author_username, p.avatar_url as author_avatar,
  (select count(*) from public.chapters c where c.book_id = b.id and c.status = 'published')::int as chapter_count,
  lower(b.title || ' ' || p.name || ' ' || p.username || ' ' || coalesce(g.name, '') || ' ' ||
        coalesce(array_to_string(b.tags, ' '), '')) as search,
  b.like_count, b.audience, b.completion, b.warnings
from public.books b
join public.profiles p on p.id = b.author_id
left join public.genres g on g.id = b.genre_id
where b.status = 'published' and p.status = 'active';

grant select on public.book_cards to anon, authenticated;
