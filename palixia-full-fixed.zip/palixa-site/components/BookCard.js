import Link from 'next/link';
import Cover from '@/components/Cover';
import { fmtNum, SHOW_PUBLIC_READS, audienceLabel } from '@/lib/format';

export default function BookCard({ b }) {
  return (
    <Link href={'/book/' + b.id} className="bcard">
      <Cover b={b} />
      <div>
        <h3>{b.title}</h3>
        <span className="sub">{b.author_name}</span>
        {((b.audience && b.audience !== 'everyone') || b.completion === 'completed') && (
          <span className="sub">
            {b.completion === 'completed' && <span className="badge">Completed</span>}{' '}
            {b.audience && b.audience !== 'everyone' && <span className="badge draft">{audienceLabel(b.audience)}</span>}
          </span>
        )}
        <span className="sub">{b.genre_name}{SHOW_PUBLIC_READS && b.reads > 0 ? ' · ' + fmtNum(b.reads) + (b.reads === 1 ? ' read' : ' reads') : ''}</span>
      </div>
    </Link>
  );
}
