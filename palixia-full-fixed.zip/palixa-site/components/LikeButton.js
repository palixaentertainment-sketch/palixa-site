'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth';
import { friendlySocial } from '@/lib/errors';
import { fmtNum } from '@/lib/format';

// kind: 'book' or 'chapter'. Authors cannot like their own work, they just see the total.
export default function LikeButton({ kind, id, count, authorId, className }) {
  const { user } = useAuth();
  const table = kind === 'chapter' ? 'chapter_likes' : 'book_likes';
  const col = kind === 'chapter' ? 'chapter_id' : 'book_id';
  const [liked, setLiked] = useState(false);
  const [total, setTotal] = useState(count || 0);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState('');

  useEffect(() => { setTotal(count || 0); }, [count, id]);

  useEffect(() => {
    setLiked(false);
    if (!user || !id) return undefined;
    let alive = true;
    supabase.from(table).select(col).eq('user_id', user.id).eq(col, id).maybeSingle()
      .then(({ data }) => { if (alive) setLiked(Boolean(data)); });
    return () => { alive = false; };
  }, [user, id, table, col]);

  async function toggle() {
    if (!user) { setMsg('Log in to like this.'); return; }
    if (busy) return;
    setBusy(true); setMsg('');
    if (liked) {
      const { error } = await supabase.from(table).delete().eq('user_id', user.id).eq(col, id);
      if (error) setMsg(friendlySocial(error));
      else { setLiked(false); setTotal((t) => Math.max(0, t - 1)); }
    } else {
      const { error } = await supabase.from(table).insert({ user_id: user.id, [col]: id });
      if (error) setMsg(friendlySocial(error));
      else { setLiked(true); setTotal((t) => t + 1); }
    }
    setBusy(false);
  }

  const mine = user && authorId && user.id === authorId;
  const label = total > 0 ? fmtNum(total) : '';
  return (
    <span className="likewrap">
      {mine ? (
        total > 0 ? <span className="fine">{fmtNum(total)} {total === 1 ? 'like' : 'likes'}</span> : null
      ) : (
        <button type="button" className={(className || 'btn ghost') + (liked ? ' on' : '')} aria-pressed={liked} onClick={toggle} disabled={busy}>
          <span aria-hidden="true">{liked ? '♥' : '♡'}</span> {liked ? 'Liked' : 'Like'}{label ? ' · ' + label : ''}
        </button>
      )}
      {msg && <span className="msg-err" role="alert"> {msg} {!user && <Link className="linkbtn" href={'/login?next=' + (typeof window !== 'undefined' ? encodeURIComponent(window.location.pathname) : '/')}>Log in</Link>}</span>}
    </span>
  );
}
