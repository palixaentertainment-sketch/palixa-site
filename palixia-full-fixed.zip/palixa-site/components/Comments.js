'use client';
import { useCallback, useEffect, useState } from 'react';
import Link from 'next/link';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth';
import { friendlySocial } from '@/lib/errors';
import ReportButton from '@/components/ReportButton';

function ago(iso) {
  const s = Math.max(0, (Date.now() - new Date(iso).getTime()) / 1000);
  if (s < 60) return 'just now';
  if (s < 3600) return Math.floor(s / 60) + ' min ago';
  if (s < 86400) return Math.floor(s / 3600) + ' h ago';
  if (s < 86400 * 30) return Math.floor(s / 86400) + ' d ago';
  return new Date(iso).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' });
}

function Composer({ placeholder, onSend, onCancel, initial, cta }) {
  const [text, setText] = useState(initial || '');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  async function submit(e) {
    e.preventDefault();
    if (!text.trim()) { setErr('Write something first.'); return; }
    setBusy(true); setErr('');
    const problem = await onSend(text);
    setBusy(false);
    if (problem) setErr(problem); else setText('');
  }
  return (
    <form className="cform" onSubmit={submit}>
      <label className="sr-only" htmlFor={'c-' + (placeholder || 'x')}>Comment</label>
      <textarea id={'c-' + (placeholder || 'x')} className="in" value={text} maxLength={1000} onChange={(e) => setText(e.target.value)} placeholder={placeholder} rows={3} />
      <p className="msg-err" role="alert">{err}</p>
      <span className="row">
        <button className="btn small" type="submit" disabled={busy}>{busy ? 'Posting...' : cta || 'Post'}</button>
        {onCancel && <button className="btn ghost small" type="button" onClick={onCancel}>Cancel</button>}
      </span>
    </form>
  );
}

export default function Comments({ chapterId, authorId }) {
  const { user } = useAuth();
  const [rows, setRows] = useState(null);
  const [failed, setFailed] = useState(false);
  const [replyTo, setReplyTo] = useState(null);
  const [editing, setEditing] = useState(null);
  const [note, setNote] = useState('');

  const load = useCallback(async () => {
    const { data, error } = await supabase
      .from('comments')
      .select('id,user_id,parent_id,body,status,created_at,updated_at,profiles(name,username)')
      .eq('chapter_id', chapterId)
      .order('created_at', { ascending: true })
      .limit(200);
    if (error) { setFailed(true); setRows([]); return; }
    setFailed(false);
    setRows((data || []).filter((c) => c.status === 'visible' || (user && c.user_id === user.id)));
  }, [chapterId, user]);

  useEffect(() => { setRows(null); load(); }, [load]);

  async function post(body, parentId) {
    const { error } = await supabase.from('comments').insert({ chapter_id: chapterId, user_id: user.id, parent_id: parentId || null, body });
    if (error) return friendlySocial(error);
    setReplyTo(null);
    await load();
    return '';
  }
  async function saveEdit(id, body) {
    const { error } = await supabase.from('comments').update({ body: body.trim(), updated_at: new Date().toISOString() }).eq('id', id);
    if (error) return friendlySocial(error);
    setEditing(null);
    await load();
    return '';
  }
  async function remove(id) {
    if (typeof window !== 'undefined' && !window.confirm('Delete this comment?')) return;
    setNote('');
    const { error } = await supabase.from('comments').delete().eq('id', id);
    if (error) { setNote(friendlySocial(error)); return; }
    await load();
  }

  const tops = (rows || []).filter((c) => !c.parent_id);
  const kids = (id) => (rows || []).filter((c) => c.parent_id === id);

  function Item({ c, isReply }) {
    const mine = user && c.user_id === user.id;
    const byAuthor = c.user_id === authorId;
    const canDelete = mine || (user && user.id === authorId);
    const p = c.profiles;
    return (
      <li className={'comment' + (isReply ? ' reply' : '')}>
        <p className="chead">
          {p ? <Link className="linkbtn" href={'/author/' + p.username}>{p.name}</Link> : <b>Reader</b>}
          {byAuthor && <span className="badge">Author</span>}
          <span className="fine">{ago(c.created_at)}{c.updated_at && new Date(c.updated_at) - new Date(c.created_at) > 1000 ? ' (edited)' : ''}</span>
          {c.status === 'hidden' && <span className="badge draft">Hidden</span>}
        </p>
        {editing === c.id ? (
          <Composer initial={c.body} cta="Save" placeholder={'edit-' + c.id} onSend={(t) => saveEdit(c.id, t)} onCancel={() => setEditing(null)} />
        ) : (
          <p className="cbody">{c.body}</p>
        )}
        {editing !== c.id && (
          <p className="cact">
            {user && !isReply && <button type="button" className="linkbtn fine" onClick={() => setReplyTo(replyTo === c.id ? null : c.id)}>Reply</button>}
            {mine && <button type="button" className="linkbtn fine" onClick={() => setEditing(c.id)}>Edit</button>}
            {canDelete && <button type="button" className="linkbtn fine" onClick={() => remove(c.id)}>Delete</button>}
            {!mine && <ReportButton type="comment" id={c.id} />}
          </p>
        )}
        {replyTo === c.id && (
          <Composer placeholder={'reply-' + c.id} cta="Reply" onSend={(t) => post(t, c.id)} onCancel={() => setReplyTo(null)} />
        )}
        {!isReply && kids(c.id).length > 0 && (
          <ul className="clist">{kids(c.id).map((k) => <Item key={k.id} c={k} isReply />)}</ul>
        )}
      </li>
    );
  }

  const total = rows ? rows.length : 0;
  return (
    <section className="comments" aria-label="Comments">
      <h2 className="h2">Comments{total > 0 ? ' (' + total + ')' : ''}</h2>
      {user ? (
        <Composer placeholder="Share what you thought of this chapter" onSend={(t) => post(t, null)} />
      ) : (
        <p className="fine"><Link className="linkbtn" href={'/login?next=' + encodeURIComponent(typeof window !== 'undefined' ? window.location.pathname : '/')}>Log in</Link> to join the conversation.</p>
      )}
      {note && <p className="msg-err" role="alert">{note}</p>}
      {failed && <p className="fine">Comments could not load right now.</p>}
      {rows === null && <p className="fine">Loading comments...</p>}
      {rows && rows.length === 0 && !failed && <p className="fine">No comments yet. Be the first.</p>}
      {tops.length > 0 && <ul className="clist">{tops.map((c) => <Item key={c.id} c={c} />)}</ul>}
    </section>
  );
}
