'use client';
import { useState } from 'react';
import Link from 'next/link';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth';
import { friendlySocial } from '@/lib/errors';

const REASONS = [
  ['spam', 'Spam'],
  ['abuse', 'Abuse or harassment'],
  ['inappropriate', 'Inappropriate content'],
  ['copyright', 'Copyright'],
  ['other', 'Something else'],
];

// type: 'comment' or 'book'
export default function ReportButton({ type, id, label }) {
  const { user } = useAuth();
  const [open, setOpen] = useState(false);
  const [reason, setReason] = useState('spam');
  const [details, setDetails] = useState('');
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState('');
  const [done, setDone] = useState(false);

  async function send(e) {
    e.preventDefault();
    setBusy(true); setMsg('');
    const { error } = await supabase.from('reports').insert({ target_type: type, target_id: id, reason, details: details.trim() || null });
    setBusy(false);
    if (error) {
      setMsg(error.code === '23505' ? 'You have already reported this. Thank you.' : friendlySocial(error));
      return;
    }
    setDone(true); setOpen(false);
  }

  if (done) return <span className="fine">Reported. Thank you.</span>;
  if (!open) {
    return <button type="button" className="linkbtn fine" onClick={() => setOpen(true)}>{label || 'Report'}</button>;
  }
  if (!user) {
    return <span className="fine">Log in to report. <Link className="linkbtn" href={'/login?next=' + encodeURIComponent(typeof window !== 'undefined' ? window.location.pathname : '/')}>Log in</Link> <button type="button" className="linkbtn" onClick={() => setOpen(false)}>Cancel</button></span>;
  }
  return (
    <form className="reportform" onSubmit={send}>
      <label className="sr-only" htmlFor={'rr-' + id}>Reason</label>
      <select id={'rr-' + id} className="in" value={reason} onChange={(e) => setReason(e.target.value)}>
        {REASONS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
      </select>
      <label className="sr-only" htmlFor={'rd-' + id}>Details (optional)</label>
      <input id={'rd-' + id} className="in" value={details} maxLength={500} onChange={(e) => setDetails(e.target.value)} placeholder="Details (optional)" />
      {msg && <span className="msg-err" role="alert">{msg}</span>}
      <span className="row">
        <button className="btn small" type="submit" disabled={busy}>{busy ? 'Sending...' : 'Send report'}</button>
        <button className="btn ghost small" type="button" onClick={() => setOpen(false)}>Cancel</button>
      </span>
    </form>
  );
}
