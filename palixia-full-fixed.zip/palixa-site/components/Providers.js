'use client';
import { usePathname } from 'next/navigation';
import Link from 'next/link';
import PublishLink from '@/components/PublishLink';
import { AuthProvider } from '@/lib/auth';
import Header from '@/components/Header';
import AuthHeader from '@/components/AuthHeader';
import Logo from '@/components/Logo';
import MobileNav from '@/components/MobileNav';

export default function Providers({ children }) {
  const pathname = usePathname() || '/';
  const reading = pathname.startsWith('/read/');
  const signingIn = ['/login', '/signup', '/forgot-password', '/reset-password'].some((p) => pathname.startsWith(p));
  return (
    <AuthProvider>
      {reading ? (
        children
      ) : (
        <>
          {signingIn ? <AuthHeader /> : <Header />}
          <main className="wrap page">{children}</main>
          <footer className="wrap foot">
            <Logo size="footer" />
            <nav aria-label="Footer">
              <Link href="/discover">Discover</Link>
              <Link href="/categories">Categories</Link>
              <Link href="/authors">Authors</Link>
              <Link href="/about">About</Link>
              <Link href="/terms">Terms</Link>
              <Link href="/privacy">Privacy</Link>
              <PublishLink className="">Publish with Palixia</PublishLink>
            </nav>
            <p className="fine">&copy; Palixia.</p>
          </footer>
          <MobileNav />
        </>
      )}
    </AuthProvider>
  );
}
